﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Assignment2_17272381.Models
{
    public class ParkingSpaceImage
    {
        public int ID { get; set; }
        [Display(Name = "File")]
        [StringLength(100)]
        [Index(IsUnique = true)]
        public string FileName { get; set; }
        public virtual ICollection<ParkingSpaceImageMapping> ParkingSpaceImageMappings { get; set; }

    }
}