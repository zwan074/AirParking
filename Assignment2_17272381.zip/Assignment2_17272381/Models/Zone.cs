﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Assignment2_17272381.Models
{
    public class Zone
    {
        [Key]
        public int ID { get; set; }

        [Required(ErrorMessage = "The Zone name cannot be blank")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Please enter a Zone name between 3 and 50 characters in length")]
        [RegularExpression(@"^[A-Z]+[a-zA-Z''-'\s]*$", ErrorMessage = "Please enter a Zone name beginning with a capital letter and enter only letters and spaces.")]
        [Display(Name = "Zone")]
        public string Suburb { get; set; }

        [Required(ErrorMessage = "The City name cannot be blank")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Please enter a City name between 3 and 50 characters in length")]
        [RegularExpression(@"^[A-Z]+[a-zA-Z''-'\s]*$", ErrorMessage = "Please enter a City name beginning with a capital letter and enter only letters and spaces.")]
        public string City { get; set; }

        [Required(ErrorMessage = "The Country name cannot be blank")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Please enter a Country name between 3 and 50 characters in length")]
        [RegularExpression(@"^[A-Z]+[a-zA-Z''-'\s]*$", ErrorMessage = "Please enter a Country name beginning with a capital letter and enter only letters and spaces.")]
        public string Country { get; set; }
        public virtual ICollection<ParkingSpace> ParkingSpaces { get; set; }
    }
}