﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Assignment2_17272381
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            
            routes.MapRoute(
                name: "ParkingSpacesCreate",
                url: "ParkingSpaces/Create",
                defaults: new { controller = "ParkingSpaces", action = "Create" }
                );

            routes.MapRoute(
              name: "ParkingSpacesIndex",
              url: "ParkingSpaces",
              defaults: new { controller = "ParkingSpaces", action = "Index" }
              );

            routes.MapRoute(
              name: "ParkingSpacesbyCategoryByPage",
              url: "ParkingSpaces/{Zone}/Page{page}",
              defaults: new { controller = "ParkingSpaces", action = "Index" }
              );

            

            routes.MapRoute(
               name: "ParkingSpacesbyPage",
               url: "ParkingSpaces/Page{page}",
               defaults: new { controller = "ParkingSpaces", action = "Index" }
               );

            routes.MapRoute(
                name: "ParkingSpacesByCategory",
                url: "ParkingSpaces/{Zone}",
                defaults: new { controller = "ParkingSpaces", action = "Index" }
                );
            
            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
