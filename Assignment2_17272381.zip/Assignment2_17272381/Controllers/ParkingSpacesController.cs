﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Assignment2_17272381.Models;
using Assignment2_17272381.OSDB;
using Assignment2_17272381.ViewModels;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using PagedList;

namespace Assignment2_17272381.Controllers
{
    
    [Authorize( Roles = "Admin,Users") ]
      
    public class ParkingSpacesController : Controller
    {
        
        private StoreContext db = new StoreContext();
        
        private ApplicationUserManager _userManager;
        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            set
            {
                _userManager = value;
            }
        }
        private ApplicationRoleManager _roleManager;
        public ApplicationRoleManager RoleManager
        {
            get
            {
                return _roleManager ?? HttpContext.GetOwinContext().Get<ApplicationRoleManager>();
            }
            private set
            {
                _roleManager = value;
            }
        }

        // GET: ParkingSpaces
        [AllowAnonymous]
        public ActionResult Index(string zone, string search, string sortBy, int? page)
        {
            ParkingSpaceIndexViewModel viewModel = new ParkingSpaceIndexViewModel();
            var parkingSpaces = db.ParkingSpaces.Include(p => p.Zone);
            
            if (!string.IsNullOrEmpty(search))
            {
                parkingSpaces = parkingSpaces.Where(p => p.Location.AddressLine1.Contains(search) ||
                p.Location.AddressLine2.Contains(search) ||
                p.Location.Town.Contains(search) ||
                p.Location.Country.Contains(search) ||
                p.Description.Contains(search) ||
                p.Zone.Suburb.Contains(search));
                viewModel.Search = search;
            }

            viewModel.ZonesWithCount = from matchingParkingSpaces in parkingSpaces
                                      where
                                      matchingParkingSpaces.ZoneID != null
                                      group matchingParkingSpaces by
                                      matchingParkingSpaces.Zone.Suburb into
                                      zoneGroup
                                      select new ZoneWithCount()
                                      {
                                          ZoneName = zoneGroup.Key,
                                          ParkingSpaceCount = zoneGroup.Count()
                                      };
            //var zones = parkingSpaces.OrderBy(p => p.Zone.Suburb).Select(p => p.Zone.Suburb).Distinct();

            if (!String.IsNullOrEmpty(zone))
            {
                parkingSpaces = parkingSpaces.Where(p => p.Zone.Suburb == zone);
                viewModel.Zone = zone;
            }
            
            switch (sortBy)
            {
                case "price_lowest":
                    parkingSpaces = parkingSpaces.OrderBy(p => p.Price);
                    break;
                case "price_highest":
                    parkingSpaces = parkingSpaces.OrderByDescending(p => p.Price);
                    break;
                default:
                    parkingSpaces = parkingSpaces.OrderBy(p => p.Location.AddressLine1);
                    break;

            }

            //viewModel.ParkingSpaces = parkingSpaces;
            //const int PageItems = 3;
            int currentPage = (page ?? 1);
            viewModel.ParkingSpaces = parkingSpaces.ToPagedList(currentPage, Constants.PagedItems);
            //viewModel.Products = products;
            viewModel.SortBy = sortBy;

            viewModel.Sorts = new Dictionary <string, string>
            {
                { "Price low to high", "price_lowest" },
                { "Price high to low", "price_highest" }
            };

            //ViewBag.Zone = new SelectList(zones);
            //return View(parkingSpaces.ToList());
            return View(viewModel);
        }

        // GET: ParkingSpaces/Details/5
        [AllowAnonymous]
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ParkingSpace parkingSpace = db.ParkingSpaces.Find(id);
            if (parkingSpace == null)
            {
                return HttpNotFound();
            }
            return View(parkingSpace);
        }

        // GET: ParkingSpaces/Create
       
        public ActionResult Create()
        {
            //ViewBag.CategoryID = new SelectList(db.Categories, "ID", "Name");
            //return View();

            ParkingSpaceViewModel viewModel = new ParkingSpaceViewModel
            {
                ZoneList = new SelectList(db.Zones, "ID", "Suburb"),
                ImageLists = new List<SelectList>(),
                ListingDate = DateTime.Now,

            };
            for (int i = 0; i < Constants.NumberOfParkingSpaceImages; i++)
            {
                viewModel.ImageLists.Add(new SelectList(db.ParkingSpaceImages, "ID", "FileName"));
            }
            return View(viewModel);

        }

        // POST: ParkingSpaces/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(ParkingSpaceViewModel viewModel)
        {
            ParkingSpace parkingSpace = new ParkingSpace
            {
                Location = viewModel.Location,
                NumberOfParks = viewModel.NumberOfParks,
                Description = viewModel.Description,
                ListingDate = DateTime.Now,
                AvailableDate = viewModel.AvailableDate,
                Price = viewModel.Price,
                UserID = User.Identity.Name,
                ZoneID = viewModel.ZoneID,
                ParkingSpaceImageMappings = new List<ParkingSpaceImageMapping>()
            };
            //get a list of selected Images without any blanks
            string[] productImages = viewModel.ParkingSpaceImages.Where(pi => !string.IsNullOrEmpty(pi)).ToArray();
            for (int i = 0; i < productImages.Length; i++)
            {
                parkingSpace.ParkingSpaceImageMappings.Add(new ParkingSpaceImageMapping
                {
                    ParkingSpaceImage = db.ParkingSpaceImages.Find(int.Parse(productImages[i])),
                    ImageNumber = i
                });
            }
            if (ModelState.IsValid)
            {
                db.ParkingSpaces.Add(parkingSpace);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            viewModel.ZoneList = new SelectList(db.Zones, "ID", "Suburb", parkingSpace.ZoneID);
            viewModel.ImageLists = new List<SelectList>();
            for (int i = 0; i < Constants.NumberOfParkingSpaceImages; i++)
            {
                viewModel.ImageLists.Add(new SelectList(db.ParkingSpaceImages, "ID", "FileName", viewModel.ParkingSpaceImages[i]));
            }
            // ViewBag.CategoryID = new SelectList(db.Categories, "ID", "Name", product.CategoryID);
            return View(viewModel);
        }

        // GET: ParkingSpaces/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            
            
            ParkingSpace parkingSpace = db.ParkingSpaces.Find(id);
            if (parkingSpace == null)
            {
                return HttpNotFound();
            }

            ParkingSpaceViewModel viewModel = new ParkingSpaceViewModel
            {
                ZoneList = new SelectList(db.Zones, "ID", "Suburb", parkingSpace.ZoneID),
                ImageLists = new List<SelectList>()
            };
            foreach (var imageMapping in parkingSpace.ParkingSpaceImageMappings.OrderBy(pim => pim.ImageNumber))
            {
                viewModel.ImageLists.Add(new SelectList(db.ParkingSpaceImages, "ID", "FileName",
                imageMapping.ParkingSpaceImageID));
            }
            for (int i = viewModel.ImageLists.Count; i < Constants.NumberOfParkingSpaceImages; i++)
            {
                viewModel.ImageLists.Add(new SelectList(db.ParkingSpaceImages, "ID", "FileName"));
            }
            viewModel.ID = parkingSpace.ID;
            viewModel.Location = parkingSpace.Location;
            viewModel.Description = parkingSpace.Description;
            viewModel.ListingDate = parkingSpace.ListingDate;
            viewModel.AvailableDate = parkingSpace.AvailableDate;
            viewModel.Price = parkingSpace.Price;
            viewModel.UserID = parkingSpace.UserID;
            viewModel.ZoneID = (int) parkingSpace.ZoneID;

            //user can edit its own post and stop HTML injection
            var userId = User.Identity.Name;
            if (userId != parkingSpace.UserID && User.IsInRole("Users"))
            {
                return RedirectToAction("Index");
            }

            return View(viewModel);

            //ViewBag.ZoneID = new SelectList(db.Zones, "ID", "Suburb", parkingSpace.ZoneID);
            //return View(parkingSpace);
        }

        // POST: ParkingSpaces/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        
        public ActionResult Edit(ParkingSpaceViewModel viewModel)
        {
            var parkingSpaceToUpdate = db.ParkingSpaces.Include(p => p.ParkingSpaceImageMappings).Where(p => p.ID == viewModel.ID).Single();
            if (TryUpdateModel(parkingSpaceToUpdate, "", new string[] { "Location", "NumberOfParks","ListingDate","AvailableDate", "Description", "Price", "ZoneID" }))
            {
                if (parkingSpaceToUpdate.ParkingSpaceImageMappings == null)
                {
                    parkingSpaceToUpdate.ParkingSpaceImageMappings = new List<ParkingSpaceImageMapping>();
                }
                //get a list of selected Images without any Blanks
                string[] parkingSpaceImages = viewModel.ParkingSpaceImages.Where(pi => !string.IsNullOrEmpty(pi)).ToArray();
                for (int i = 0; i < parkingSpaceImages.Length; i++)
                {
                    //get the image currently stored
                    var imageMappingToEdit = parkingSpaceToUpdate.ParkingSpaceImageMappings.Where(pim => pim.ImageNumber == i).FirstOrDefault();
                    //find the new image
                    var image = db.ParkingSpaceImages.Find(int.Parse(parkingSpaceImages[i]));
                    //if there is nothing stored then we need to add new mapping
                    if (imageMappingToEdit == null)
                    {
                        //add image to the imagemappings
                        parkingSpaceToUpdate.ParkingSpaceImageMappings.Add(new ParkingSpaceImageMapping
                        {
                            ImageNumber = i,
                            ParkingSpaceImage = image,
                            ParkingSpaceImageID = image.ID
                        });
                    }
                    //else its not a new file so edit the current mapping
                    else
                    {
                        //if they are not the same
                        if (imageMappingToEdit.ParkingSpaceImageID != int.Parse(parkingSpaceImages[i]))
                        {
                            //assign image property of the image mapping

                            imageMappingToEdit.ParkingSpaceImage = image;
                        }
                    }
                }
                //delete any other imagemappings that the user did not include in their selections for the product
                for (int i = parkingSpaceImages.Length; i < Constants.NumberOfParkingSpaceImages; i++)
                {
                    var imageMappingToEdit = parkingSpaceToUpdate.ParkingSpaceImageMappings.Where(pim => pim.ImageNumber == i).FirstOrDefault();
                    //if there is something stored in the mapping
                    if (imageMappingToEdit != null)
                    {
                        //delete the record form the mapping table directly
                        //just calling productToUpdate.ProductImageMappings.Remove(imageMappingToEdit)
                        //results in a FK error
                        db.ParkingSpaceImageMappings.Remove(imageMappingToEdit);
                    }
                }
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(viewModel);
        }

        // GET: Products/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ParkingSpace parkingSpace = db.ParkingSpaces.Find(id);
            if (parkingSpace == null)
            {
                return HttpNotFound();
            }

            //user can delete its own post and stop HTML injection
            var userId = User.Identity.Name;
            if (userId != parkingSpace.UserID && User.IsInRole("Users"))
            {
                return RedirectToAction("Index");
            }
            return View(parkingSpace);
        }

        // POST: ParkingSpaces/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            ParkingSpace parkingSpace = db.ParkingSpaces.Find(id);
            db.ParkingSpaces.Remove(parkingSpace);
            var orderLines = db.OrderLines.Where(ol => ol.ParkingSpaceID == id);
            foreach (var ol in orderLines)
            {
                ol.ParkingSpaceID = null;
            }

            db.SaveChanges();
            return RedirectToAction("Index");
        }



       


        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
